from huggingface_hub import snapshot_download
snapshot_download(repo_id="MonsterMMORPG/examples2",local_dir="Example_Face_Video_To_Test")